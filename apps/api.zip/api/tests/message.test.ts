import {
  jest,
  beforeAll,
  beforeEach,
  describe,
  it,
  expect
} from '@jest/globals'
import type { PrismaClient } from '@prisma/client'
import type { Mocked } from 'jest-mock'

jest.unstable_mockModule('../src/lib/redis', () => ({
  redis: {
    isReady: true,
    ping: jest.fn<() => Promise<string>>().mockResolvedValue('PONG'),
    connect: jest.fn<() => Promise<void>>().mockResolvedValue(undefined),
    on: jest.fn(),
    get: jest.fn<() => Promise<string | null>>().mockResolvedValue(null),
    set: jest.fn<() => Promise<string>>().mockResolvedValue('OK'),
    lRange: jest.fn<() => Promise<string[]>>().mockResolvedValue([]),
    lPush: jest.fn<() => Promise<number>>().mockResolvedValue(1),
    rPush: jest.fn<() => Promise<number>>().mockResolvedValue(1),
    lRem: jest.fn<() => Promise<number>>().mockResolvedValue(1),
    lSet: jest.fn<() => Promise<string>>().mockResolvedValue('OK'),
    lTrim: jest.fn<() => Promise<string>>().mockResolvedValue('OK'),
    lLen: jest.fn<() => Promise<number>>().mockResolvedValue(0),
    expire: jest.fn<() => Promise<boolean>>().mockResolvedValue(true),
    del: jest.fn<() => Promise<number>>().mockResolvedValue(1)
  }
}))

let request: Awaited<typeof import('supertest')>['default']
let app: Awaited<typeof import('../src/app')>['app']
let db: Mocked<PrismaClient>
let redisMock: Mocked<Awaited<typeof import('../src/lib/redis')>['redis']>
let mockMessage1: Awaited<typeof import('./fixtures')>['mockMessage1']
let mockMessage2: Awaited<typeof import('./fixtures')>['mockMessage2']
let mockMessageWithAttachment: Awaited<
  typeof import('./fixtures')
>['mockMessageWithAttachment']

beforeAll(async () => {
  const supertest = await import('supertest')
  request = supertest.default

  const appMod = await import('../src/app')
  app = appMod.app

  const { prisma } = await import('../src/lib')
  db = prisma as Mocked<PrismaClient>

  const { redis } = await import('../src/lib/redis')
  redisMock = redis as typeof redisMock

  const fixtures = await import('./fixtures')
  mockMessage1 = fixtures.mockMessage1
  mockMessage2 = fixtures.mockMessage2
  mockMessageWithAttachment = fixtures.mockMessageWithAttachment
})

beforeEach(() => {
  jest.clearAllMocks()
})

describe('GET /api/chats/:chatId/messages', () => {
  it('returns messages from postgres when lastId=0', async () => {
    redisMock.lRange.mockResolvedValueOnce([])
    db.message.findUnique.mockResolvedValueOnce(null)
    db.message.findMany.mockResolvedValueOnce([mockMessage2, mockMessage1])
    redisMock.rPush.mockResolvedValueOnce(2)

    const res = await request(app).get(
      '/api/chats/chat_private_001/messages?limit=20&lastId=0'
    )

    console.log(res.body)
    expect(res.status).toBe(200)
    expect(res.body).toHaveLength(2)
    expect(res.body[0].content).toBe('All good Alice, you?')
  })
})

describe('POST /api/chats/:chatId/messages', () => {
  it('creates a plain text message', async () => {
    db.message.create.mockResolvedValueOnce(mockMessage1)

    const res = await request(app)
      .post('/api/chats/chat_private_001/messages')
      .send({ userId: 'user_alice_001', content: 'Hey Bob, how are you?' })

    expect(res.status).toBe(201)
  })

  it('creates a message with an attachment', async () => {
    db.message.create.mockResolvedValueOnce(mockMessageWithAttachment)

    const res = await request(app)
      .post('/api/chats/chat_group_002/messages')
      .send({
        userId: 'user_alice_001',
        content: 'Check this out',
        attachments: [
          { url: 'https://cdn.ouija.dev/files/report.pdf', type: 'FILE' }
        ]
      })

    expect(res.status).toBe(201)
  })

  it('returns 500 if content is null', async () => {
    const res = await request(app)
      .post('/api/chats/chat_private_001/messages')
      .send({ userId: 'user_alice_001', content: null })

    expect(res.status).toBe(500)
    expect(res.body.error).toMatch(/null/i)
  })
})

describe('PUT /api/chats/:chatId/messages/:messageId', () => {
  it('edits message content', async () => {
    db.message.findUnique.mockResolvedValueOnce(mockMessage1)
    db.message.update.mockResolvedValueOnce({
      ...mockMessage1,
      content: 'Edited content'
    })
    redisMock.lRange.mockResolvedValueOnce([JSON.stringify(mockMessage1)])
    redisMock.lSet.mockResolvedValueOnce('OK')

    const res = await request(app)
      .put('/api/chats/chat_private_001/messages/1')
      .send({ content: 'Edited content' })

    expect(res.status).toBe(200)
    expect(res.body.content).toBe('Edited content')
  })

  it('returns 500 if message does not exist', async () => {
    db.message.findUnique.mockResolvedValueOnce(null)
    redisMock.lRange.mockResolvedValueOnce([])

    const res = await request(app)
      .put('/api/chats/chat_private_001/messages/999')
      .send({ content: 'Ghost edit' })

    expect(res.status).toBe(500)
    expect(res.body.error).toMatch(/not found/i)
  })
})

describe('DELETE /api/chats/:chatId/messages/:messageId', () => {
  it('deletes a message and returns 204', async () => {
    db.message.findUnique.mockResolvedValueOnce(mockMessage1)
    db.message.delete.mockResolvedValueOnce(mockMessage1)
    redisMock.lRange.mockResolvedValueOnce([JSON.stringify(mockMessage1)])
    redisMock.lRem.mockResolvedValueOnce(1)

    const res = await request(app).delete(
      '/api/chats/chat_private_001/messages/1'
    )

    expect(res.status).toBe(204)
  })

  it('returns 500 if message does not exist', async () => {
    db.message.findUnique.mockResolvedValueOnce(null)
    redisMock.lRange.mockResolvedValueOnce([])

    const res = await request(app).delete(
      '/api/chats/chat_private_001/messages/999'
    )

    expect(res.status).toBe(500)
    expect(res.body.error).toMatch(/not found/i)
  })
})
